<!--[metadata]>
+++
title = "Reference"
description = "Explains registry JSON objects"
keywords = ["registry, service, images, repository,  json"]
type = "menu"
[menu.main]
identifier="smn_registry_ref"
parent="smn_registry"
weight=7
+++
<![end-metadata]-->

